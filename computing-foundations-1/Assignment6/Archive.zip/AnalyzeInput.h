//Michael Launius
//Assignment 5
//AnalyzeInput.h
//Schneider

#ifndef ANALYZEINPUT_H
#define ANALYZEINPUT_H

using namespace std;

class AnalyzeInput{
	public:
	AnalyzeInput(){} //Default Constructor
	
	void analyzeCmd(string cmd, string &operation, int &arg1);//pulls data from the input


};//END

#endif